
export interface ServiceCardProps {
  title: string;
  description: string;
  image: string;
  tags: string[];
}

export interface NavItem {
  label: string;
  href: string;
}

export interface Trainer {
  name: string;
  role: string;
  description: string;
  image: string;
  specialties: string[];
}

export interface InstallationZone {
  id: string;
  title: string;
  subtitle: string;
  mainImage: string;
  gallery: string[];
}

export interface Testimonial {
  name: string;
  avatar: string;
  rating: number;
  text: string;
  discipline: string;
}
