
import React from 'react';
import { InstallationZone, Testimonial } from './types';

export const NAV_ITEMS = [
  { label: 'Inicio', href: '#inicio' },
  { label: 'Disciplinas', href: '#disciplinas' },
  { label: 'Monitores', href: '#monitores' },
  { label: 'Instalaciones', href: '#instalaciones' },
  { label: 'Reseñas', href: '#resenas' },
  { label: 'Contacto', href: '#contacto' },
];

export const TRAINERS = [
  {
    name: 'Daniel Salgado',
    role: 'Preparador Físico de Culturismo',
    description: 'Especialista en hipertrofia máxima y nutrición deportiva de élite. Transformando físicos con ciencia y disciplina.',
    image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&q=80&w=800',
    specialties: ['Hipertrofia', 'Nutrición', 'Puesta a punto']
  },
  {
    name: 'Xian Marcos',
    role: 'Entrenador de Boxeo & Artes Marciales',
    description: 'Experto en striking y combate cuerpo a cuerpo. Años de experiencia en el ring transmitiendo la técnica de los campeones.',
    image: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=800',
    specialties: ['Striking', 'MMA', 'Defensa Personal']
  },
  {
    name: 'Saul Dacosta',
    role: 'Entrenador de Trabajo Funcional',
    description: 'Dominio absoluto del movimiento humano. Especialista en core, movilidad y acondicionamiento metabólico extremo.',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=800',
    specialties: ['Movilidad', 'HIIT', 'Fuerza Aplicada']
  }
];

export const INSTALLATIONS_DATA: InstallationZone[] = [
  {
    id: 'fitness',
    title: 'Potencia & Fuerza',
    subtitle: 'Zona de Pesas Libres y Máquinas',
    mainImage: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200',
    gallery: [
      'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1593079831268-3381b0db4a77?auto=format&fit=crop&q=80&w=1200'
    ]
  },
  {
    id: 'boxeo',
    title: 'El Cuadrilátero',
    subtitle: 'Ring y Zona de Sacos',
    mainImage: 'https://images.unsplash.com/photo-1552072092-7f9b8d63efcb?auto=format&fit=crop&q=80&w=1200',
    gallery: [
      'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1508215885820-4585e56135c8?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1590556409491-0559a4358603?auto=format&fit=crop&q=80&w=1200'
    ]
  },
  {
    id: 'artes-marciales',
    title: 'Combate & Técnica',
    subtitle: 'Tatami Profesional y Dojo',
    mainImage: 'https://images.unsplash.com/photo-1555597673-b21d5c935865?auto=format&fit=crop&q=80&w=1200',
    gallery: [
      'https://images.unsplash.com/photo-1552072805-2a9039d00e57?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1599058917232-d750c1830028?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1509563268479-0f004cf3f58b?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1574673130244-c707e9d853f3?auto=format&fit=crop&q=80&w=1200'
    ]
  },
  {
    id: 'funcional',
    title: 'Elite Performance',
    subtitle: 'Zona de Cross Training',
    mainImage: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=1200',
    gallery: [
      'https://images.unsplash.com/photo-1517963879432-61f241ad9380?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1518611012118-29a8ad3b5a9a?auto=format&fit=crop&q=80&w=1200',
      'https://images.unsplash.com/photo-1521804906057-1df8fdb718b7?auto=format&fit=crop&q=80&w=1200'
    ]
  }
];

export const SERVICES = [
  {
    title: 'Boxeo & Striking',
    description: 'Domina el ring con técnica, potencia y agilidad. Clases para todos los niveles.',
    image: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=800',
    tags: ['Técnica', 'Cardio', 'Sparring']
  },
  {
    title: 'Artes Marciales',
    description: 'Entrenamiento integral que combina disciplina mental y fuerza física extrema.',
    image: 'https://images.unsplash.com/photo-1599058917232-d750c1830028?auto=format&fit=crop&q=80&w=800',
    tags: ['MMA', 'BJJ', 'Defensa Personal']
  },
  {
    title: 'Sala Fitness & Fuerza',
    description: 'Optimiza tu composición corporal con programas de hipertrofia y fuerza pura.',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800',
    tags: ['Powerlifting', 'Bodybuilding', 'Libre']
  },
  {
    title: 'Trabajo Funcional',
    description: 'Entrenamiento dinámico diseñado para mejorar tu rendimiento en la vida real.',
    image: 'https://images.unsplash.com/photo-1517963879432-61f241ad9380?auto=format&fit=crop&q=80&w=800',
    tags: ['HIIT', 'Core', 'Movilidad']
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Carlos Rivas',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    text: 'Increíble ambiente. Las clases de boxeo con Xian son de otro nivel, técnica pura y un cardio que te deja nuevo.',
    discipline: 'Boxeo'
  },
  {
    name: 'Elena Martínez',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    text: 'Daniel es un crack con la nutrición y el entrenamiento de fuerza. He conseguido en 6 meses lo que no logré en años.',
    discipline: 'Fitness & Hipertrofia'
  },
  {
    name: 'Javier Soto',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    text: 'El tatami es de primerísima calidad. Entrenar MMA aquí es una experiencia profesional total. 100% recomendable.',
    discipline: 'Artes Marciales'
  },
  {
    name: 'Marta García',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    text: 'Lo que más me gusta es la zona funcional. Saul siempre está pendiente de la técnica para evitar lesiones. ¡Top!',
    discipline: 'Trabajo Funcional'
  }
];

export const CONTACT_INFO = {
  email: 'victorbp0610@gmail.com',
  phone: '+34 666 05 47 85',
  address: 'Calle del Acero 42, Polígono Industrial San Fernando, 28830 Madrid, España'
};
