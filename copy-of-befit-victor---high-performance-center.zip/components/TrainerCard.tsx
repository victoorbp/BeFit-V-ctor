
import React from 'react';
import { Trainer } from '../types';

export const TrainerCard: React.FC<Trainer> = ({ name, role, description, image, specialties }) => {
  return (
    <div className="group relative overflow-hidden rounded-[2.5rem] bg-zinc-900 border border-white/5 hover:border-amber-500/30 transition-all duration-700">
      <div className="aspect-[3/4] overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-105 group-hover:scale-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
      </div>
      
      <div className="absolute bottom-0 p-8 w-full transform translate-y-6 group-hover:translate-y-0 transition-transform duration-500">
        <div className="text-amber-500 font-bold text-xs uppercase tracking-widest mb-2">{role}</div>
        <h3 className="text-3xl font-black mb-4 uppercase italic tracking-tighter">{name}</h3>
        
        <p className="text-zinc-400 text-sm mb-6 leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-700 delay-100">
          {description}
        </p>
        
        <div className="flex flex-wrap gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-700 delay-200">
          {specialties.map(spec => (
            <span key={spec} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] uppercase font-bold text-zinc-300">
              {spec}
            </span>
          ))}
        </div>
      </div>
      
      {/* Decorative Accent */}
      <div className="absolute top-6 right-6 w-12 h-12 border-t-2 border-r-2 border-amber-500/0 group-hover:border-amber-500/50 transition-all duration-700 rounded-tr-xl"></div>
    </div>
  );
};
