
import React from 'react';
import { ServiceCardProps } from '../types';

export const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, image, tags }) => {
  return (
    <div className="group relative overflow-hidden rounded-2xl bg-zinc-900 border border-white/5 hover:border-amber-500/50 transition-all duration-500">
      <div className="aspect-[4/3] overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />
      </div>
      
      <div className="absolute bottom-0 p-8 w-full">
        <div className="flex gap-2 mb-4">
          {tags.map(tag => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-500 border border-amber-500/30 uppercase font-bold">
              {tag}
            </span>
          ))}
        </div>
        <h3 className="text-2xl font-bold mb-2 group-hover:text-amber-500 transition-colors">{title}</h3>
        <p className="text-zinc-400 text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-500 translate-y-4 group-hover:translate-y-0">
          {description}
        </p>
      </div>
    </div>
  );
};
