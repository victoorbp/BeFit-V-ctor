
import React from 'react';
import { Testimonial } from '../types';

export const TestimonialCard: React.FC<Testimonial> = ({ name, avatar, rating, text, discipline }) => {
  return (
    <div className="bg-zinc-900/50 p-8 rounded-[2rem] border border-white/5 hover:border-amber-500/20 transition-all duration-500 group relative">
      <div className="absolute top-8 right-8 text-amber-500/10 group-hover:text-amber-500/20 transition-colors">
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H16.017C15.4647 8 15.017 8.44772 15.017 9V12C15.017 12.5523 14.5693 13 14.017 13H13.017V21H14.017ZM6.017 21L6.017 18C6.017 16.8954 6.91243 16 8.017 16H11.017C11.5693 16 12.017 15.5523 12.017 15V9C12.017 8.44772 11.5693 8 11.017 8H8.017C7.46472 8 7.017 8.44772 7.017 9V12C7.017 12.5523 6.5693 13 6.017 13H5.017V21H6.017Z" />
        </svg>
      </div>

      <div className="flex gap-1 mb-6">
        {[...Array(rating)].map((_, i) => (
          <svg key={i} className="w-5 h-5 text-amber-500" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>

      <p className="text-zinc-300 italic mb-8 relative z-10 leading-relaxed text-lg">
        "{text}"
      </p>

      <div className="flex items-center gap-4">
        <img src={avatar} alt={name} className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-500/20" />
        <div>
          <div className="font-bold text-white uppercase tracking-tighter">{name}</div>
          <div className="text-xs text-amber-500 font-bold uppercase tracking-widest">{discipline}</div>
        </div>
      </div>
    </div>
  );
};
