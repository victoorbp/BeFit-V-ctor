
import React, { useState, useEffect } from 'react';
import { InstallationZone } from '../types';

interface GalleryModalProps {
  zone: InstallationZone;
  onClose: () => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({ zone, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const images = [zone.mainImage, ...zone.gallery];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft') prev();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, []);

  const next = () => setCurrentIndex((prev) => (prev + 1) % images.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-zinc-950/95 backdrop-blur-xl p-4 md:p-10">
      <button 
        onClick={onClose}
        className="absolute top-8 right-8 text-zinc-400 hover:text-white transition-colors z-[110]"
      >
        <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>

      <div className="relative w-full max-w-6xl aspect-video md:aspect-[16/9] flex items-center justify-center">
        {/* Navigation Buttons */}
        <button 
          onClick={prev}
          className="absolute left-0 md:-left-16 text-zinc-500 hover:text-amber-500 transition-colors z-[110] p-4"
        >
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <button 
          onClick={next}
          className="absolute right-0 md:-right-16 text-zinc-500 hover:text-amber-500 transition-colors z-[110] p-4"
        >
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>

        {/* Image Container */}
        <div className="w-full h-full relative group">
          <img 
            key={currentIndex}
            src={images[currentIndex]} 
            alt={zone.title} 
            className="w-full h-full object-contain md:object-cover rounded-[2rem] shadow-2xl animate-in fade-in zoom-in duration-300"
          />
          
          <div className="absolute bottom-8 left-8 right-8 bg-black/50 backdrop-blur-md p-6 rounded-2xl border border-white/10">
            <div className="text-amber-500 font-bold text-xs uppercase tracking-widest mb-1">{zone.subtitle}</div>
            <h4 className="text-2xl font-black uppercase italic">{zone.title}</h4>
            <div className="mt-4 flex gap-2">
              {images.map((_, idx) => (
                <div 
                  key={idx} 
                  className={`h-1 flex-1 rounded-full transition-all duration-300 ${idx === currentIndex ? 'bg-amber-500' : 'bg-white/20'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
