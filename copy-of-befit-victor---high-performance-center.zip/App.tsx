
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ServiceCard } from './components/ServiceCard';
import { TrainerCard } from './components/TrainerCard';
import { GalleryModal } from './components/GalleryModal';
import { TestimonialCard } from './components/TestimonialCard';
import { SERVICES, TRAINERS, INSTALLATIONS_DATA, CONTACT_INFO, TESTIMONIALS } from './constants';
import { InstallationZone } from './types';

const App: React.FC = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [selectedZone, setSelectedZone] = useState<InstallationZone | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const elem = document.getElementById(targetId);
    if (elem) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elemRect = elem.getBoundingClientRect().top;
      const elemPosition = elemRect - bodyRect;
      const offsetPosition = elemPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      window.history.pushState(null, '', href);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950">
      <Navbar />

      {/* Hero Section */}
      <section id="inicio" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=2000" 
            alt="Gym Hero" 
            className="w-full h-full object-cover opacity-30 scale-105 animate-pulse"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/20 via-transparent to-zinc-950" />
        </div>
        
        <div className="relative z-10 text-center px-6">
          <div className="inline-block bg-amber-500/10 text-amber-500 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-[0.3em] mb-6 border border-amber-500/20">
            Premium Training Experience
          </div>
          <h1 className="text-6xl md:text-9xl font-black mb-6 tracking-tighter leading-none">
            FORJA TU <span className="text-gradient">LEGADO</span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-zinc-400 mb-10 font-light leading-relaxed">
            BeFit Victor: El centro de alto rendimiento donde el boxeo, las artes marciales 
            y la ciencia del entrenamiento convergen para crear tu mejor versión.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <a href="#disciplinas" onClick={(e) => scrollToSection(e, '#disciplinas')} className="bg-amber-500 text-black px-10 py-4 rounded-full font-bold uppercase tracking-widest hover:bg-zinc-100 transition-all shadow-[0_0_30px_rgba(245,158,11,0.3)] active:scale-95">
              Nuestros Servicios
            </a>
            <a href="#contacto" onClick={(e) => scrollToSection(e, '#contacto')} className="border border-white/20 hover:border-amber-500 hover:text-amber-500 px-10 py-4 rounded-full font-bold uppercase tracking-widest transition-all active:scale-95">
              Prueba Gratuita
            </a>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-50">
          <a href="#stats" onClick={(e) => scrollToSection(e, '#stats')} aria-label="Ver estadísticas">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </a>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" className="py-24 bg-zinc-900 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          <div className="group cursor-default">
            <div className="text-5xl md:text-6xl font-oswald font-bold text-amber-500 mb-2 transition-transform group-hover:scale-110">+500</div>
            <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Atletas Activos</div>
          </div>
          <div className="group cursor-default">
            <div className="text-5xl md:text-6xl font-oswald font-bold text-amber-500 mb-2 transition-transform group-hover:scale-110">24/7</div>
            <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Acceso Premium</div>
          </div>
          <div className="group cursor-default">
            <div className="text-5xl md:text-6xl font-oswald font-bold text-amber-500 mb-2 transition-transform group-hover:scale-110">15+</div>
            <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Maestros Pro</div>
          </div>
          <div className="group cursor-default">
            <div className="text-5xl md:text-6xl font-oswald font-bold text-amber-500 mb-2 transition-transform group-hover:scale-110">1.2k</div>
            <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Metros Cuadrados</div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="disciplinas" className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div className="max-w-2xl">
              <h2 className="text-amber-500 font-bold tracking-[0.3em] uppercase mb-4 text-sm italic underline decoration-2 underline-offset-8">Disciplinas</h2>
              <h3 className="text-4xl md:text-7xl font-black leading-none uppercase">Entrena con <span className="text-zinc-600 italic">propósito</span></h3>
            </div>
            <a href="#contacto" onClick={(e) => scrollToSection(e, '#contacto')} className="text-zinc-400 hover:text-amber-500 uppercase text-xs font-bold tracking-widest border-b border-white/10 pb-2 transition-colors">
              Ver todos los horarios →
            </a>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {SERVICES.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      {/* Trainers Section */}
      <section id="monitores" className="py-32 px-6 bg-zinc-950">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-amber-500 font-bold tracking-[0.3em] uppercase mb-4 text-sm italic">Élite Staff</h2>
            <h3 className="text-4xl md:text-7xl font-black leading-none uppercase">Nuestros <span className="text-gradient">Monitores</span></h3>
            <p className="mt-6 text-zinc-400 max-w-2xl mx-auto italic text-lg">
              No solo son entrenadores, son mentores dedicados a llevar tu rendimiento físico y mental al siguiente nivel.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {TRAINERS.map((trainer, index) => (
              <TrainerCard key={index} {...trainer} />
            ))}
          </div>
        </div>
      </section>

      {/* Installations Gallery Section */}
      <section id="instalaciones" className="py-32 px-6 bg-zinc-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-amber-500 font-bold tracking-[0.3em] uppercase mb-4 text-sm italic">Tour Virtual</h2>
            <h3 className="text-4xl md:text-6xl font-black leading-none uppercase">Nuestro <span className="text-gradient">Templo</span></h3>
            <p className="mt-6 text-zinc-400 max-w-xl mx-auto italic font-medium">Pulsa en cualquier zona para ver la galería completa.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-auto">
            {INSTALLATIONS_DATA.map((zone, index) => {
              const isLarge = index === 0 || index === 3;
              return (
                <div 
                  key={zone.id}
                  onClick={() => setSelectedZone(zone)}
                  className={`${isLarge ? 'md:col-span-2' : ''} relative group overflow-hidden rounded-[2rem] h-80 md:h-[400px] cursor-pointer ring-1 ring-white/10 hover:ring-amber-500/50 transition-all shadow-2xl`}
                >
                  <img src={zone.mainImage} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt={zone.title} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-10">
                    <span className="text-amber-500 text-xs font-black uppercase tracking-[0.3em] mb-2 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all">Ver Galería</span>
                    <span className="text-3xl font-black uppercase tracking-tighter italic group-hover:text-amber-500 transition-colors">{zone.title}</span>
                    <p className="text-zinc-400 text-sm mt-2 opacity-0 group-hover:opacity-100 transition-opacity">{zone.subtitle}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="resenas" className="py-32 px-6 bg-zinc-950">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-amber-500 font-bold tracking-[0.3em] uppercase mb-4 text-sm italic">Comunidad</h2>
            <h3 className="text-4xl md:text-7xl font-black leading-none uppercase">Lo que dicen <br/><span className="text-gradient">nuestros atletas</span></h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {TESTIMONIALS.map((testimonial, index) => (
              <TestimonialCard key={index} {...testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Modal */}
      {selectedZone && (
        <GalleryModal zone={selectedZone} onClose={() => setSelectedZone(null)} />
      )}

      {/* Contact Section */}
      <section id="contacto" className="py-32 px-6 bg-zinc-900">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div>
            <h2 className="text-amber-500 font-bold tracking-[0.3em] uppercase mb-4 text-sm italic">Contacto</h2>
            <h3 className="text-5xl md:text-7xl font-black mb-10 leading-none uppercase">TU LUGAR ES <br/><span className="text-gradient italic">AQUÍ</span></h3>
            
            <div className="space-y-10">
              <div className="flex items-center gap-6 group">
                <div className="w-16 h-16 rounded-2xl bg-zinc-900 flex items-center justify-center border border-white/5 group-hover:border-amber-500/50 group-hover:bg-amber-500/5 transition-all">
                   <svg className="w-7 h-7 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 mb-1 font-bold">Email</div>
                  <div className="text-xl font-bold hover:text-amber-500 transition-colors cursor-pointer">{CONTACT_INFO.email}</div>
                </div>
              </div>

              <div className="flex items-center gap-6 group">
                <div className="w-16 h-16 rounded-2xl bg-zinc-900 flex items-center justify-center border border-white/5 group-hover:border-amber-500/50 group-hover:bg-amber-500/5 transition-all">
                   <svg className="w-7 h-7 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 mb-1 font-bold">Llámanos</div>
                  <div className="text-xl font-bold hover:text-amber-500 transition-colors cursor-pointer">{CONTACT_INFO.phone}</div>
                </div>
              </div>

              <div className="flex items-center gap-6 group">
                <div className="w-16 h-16 rounded-2xl bg-zinc-900 flex items-center justify-center border border-white/5 group-hover:border-amber-500/50 group-hover:bg-amber-500/5 transition-all">
                   <svg className="w-7 h-7 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-zinc-500 mb-1 font-bold">Gimnasio</div>
                  <div className="text-lg font-bold max-w-xs leading-snug">{CONTACT_INFO.address}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-zinc-950 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative">
            <div className="absolute top-0 right-10 -translate-y-1/2 bg-amber-500 text-black px-6 py-2 rounded-full font-black text-xs uppercase italic tracking-widest shadow-xl">
              1ª Clase Gratis
            </div>
            <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert('¡Recibido! Víctor se pondrá en contacto contigo muy pronto.'); }}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black tracking-[0.2em] text-zinc-500 px-1">Nombre</label>
                  <input required type="text" className="w-full bg-zinc-900 border border-white/5 p-5 rounded-2xl focus:outline-none focus:border-amber-500 transition-all text-white placeholder:text-zinc-700" placeholder="Ej: Juan" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black tracking-[0.2em] text-zinc-500 px-1">Email</label>
                  <input required type="email" className="w-full bg-zinc-900 border border-white/5 p-5 rounded-2xl focus:outline-none focus:border-amber-500 transition-all text-white placeholder:text-zinc-700" placeholder="juan@gmail.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-[0.2em] text-zinc-500 px-1">¿Qué te interesa?</label>
                <select className="w-full bg-zinc-900 border border-white/5 p-5 rounded-2xl focus:outline-none focus:border-amber-500 transition-all text-white appearance-none cursor-pointer">
                  <option>Boxeo & Striking</option>
                  <option>Artes Marciales (MMA)</option>
                  <option>Fitness & Hipertrofia</option>
                  <option>Cross Training / Funcional</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-[0.2em] text-zinc-500 px-1">Mensaje (Opcional)</label>
                <textarea className="w-full bg-zinc-900 border border-white/5 p-5 rounded-2xl focus:outline-none focus:border-amber-500 transition-all h-32 text-white placeholder:text-zinc-700" placeholder="Cuéntanos tus metas..."></textarea>
              </div>
              <button type="submit" className="w-full bg-amber-500 text-black py-6 rounded-2xl font-black uppercase tracking-[0.2em] hover:bg-zinc-100 transition-all shadow-xl active:scale-95 text-lg">
                Enviar Solicitud
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-white/5 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center rotate-3">
              <span className="text-black font-black italic text-xl">V</span>
            </div>
            <span className="text-2xl font-oswald font-bold tracking-tighter">
              BEFIT <span className="text-amber-500 italic">VICTOR</span>
            </span>
          </div>
          
          <div className="text-zinc-600 text-sm font-medium tracking-wide text-center">
            © {new Date().getFullYear()} BeFit Victor. Todos los derechos reservados. <br className="md:hidden"/>
            Entrenamos para ganar.
          </div>

          <div className="flex gap-8 text-zinc-500">
            <a href="#" className="hover:text-amber-500 transition-all transform hover:scale-110">IG</a>
            <a href="#" className="hover:text-amber-500 transition-all transform hover:scale-110">TK</a>
            <a href="#" className="hover:text-amber-500 transition-all transform hover:scale-110">YT</a>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      <button 
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-8 right-8 bg-amber-500 text-black p-4 rounded-2xl shadow-[0_10px_30px_rgba(245,158,11,0.4)] z-50 hover:bg-zinc-100 transition-all transform active:scale-90 ${showScrollTop ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-20 opacity-0 scale-50'}`}
        aria-label="Back to top"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
      </button>
    </div>
  );
};

export default App;
